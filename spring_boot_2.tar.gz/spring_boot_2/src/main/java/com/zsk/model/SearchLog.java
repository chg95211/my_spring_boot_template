package com.zsk.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.io.Serializable;
import java.util.Date;

/*
 * @Description:
 * @Author: ZHANGSHENGKUN938
 * @Date: 2018-09-30 15:19
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document(indexName = "search_log2", type = "search_log2", shards = 1, replicas = 1)
public class SearchLog implements Serializable
{
    @Id
    @Field(type = FieldType.Keyword)
    private String id;

    /*
    测试分词效果
    GET /search_log/_analyze
    {
	"field":"q",
	"text":"好像似乎"
    }
     */
    @Field(type = FieldType.Text)
    private String q; //搜索的关键词

    @Field(type = FieldType.Date)
    private Date date; //搜索日期

    @Field(type = FieldType.Keyword)
    private String um; //搜索的用户um
}
