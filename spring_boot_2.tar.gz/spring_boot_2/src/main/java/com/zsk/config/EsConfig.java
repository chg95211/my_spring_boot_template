package com.zsk.config;

import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.TransportAddress;
import org.elasticsearch.xpack.client.PreBuiltXPackTransportClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * @description:
 * @author: zsk
 * @create: 2019-08-07 21:08
 **/
@Configuration
public class EsConfig
{
    @Bean
    public TransportClient transportClient() throws UnknownHostException
    {
        return new PreBuiltXPackTransportClient(Settings.builder()
                .put("cluster.name", "myes")
                .put("xpack.security.user", "elastic:zskroot")
                .build())
                .addTransportAddress(new TransportAddress(InetAddress.getByName("127.0.0.1"), 9300));
    }
}
