package com.zsk.dao;

import com.zsk.model.SearchLog;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

/**
 * @description:
 * @author: zsk
 * @create: 2019-08-07 20:20
 **/
@Repository
public interface SearchLogDao extends ElasticsearchRepository<SearchLog, String>
{
}
