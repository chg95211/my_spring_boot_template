import com.zsk.Application;
import com.zsk.dao.SearchLogDao;
import com.zsk.model.SearchLog;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.Date;

/**
 * @description:
 * @author: zsk
 * @create: 2019-05-11 16:45
 **/
@Slf4j
@SpringBootTest(classes = Application.class)
@RunWith(SpringJUnit4ClassRunner.class)
public class TestApplication
{

    @Autowired
    private SearchLogDao logDao;


    @Test
    public void testCreateIndex(){
        logDao.save(SearchLog.builder().id("bbbb").q("test").date(new Date()).um("zsk").build());
        System.out.println("需要有es dao和 model类才会自动创建");
    }

//    @Autowired
//    private ElasticsearchTemplate elasticsearchTemplate;

//    @Test
//    public void testElasticsearchTemplate()
//    {
//        elasticsearchTemplate.refresh(Ttest.class);
//    }

//    @Test
//    public void testSaveIndex()
//    {
//        Ttest ttestWithSubs2 = ttestDao.getTtestWithSubs2(1);
//        tTestEsDao.save(ttestWithSubs2);
//    }

}
